<?php

error_reporting(0);
$_76d3154645 = "\x1b[44m";
$_68ba588d15 = "\x1b[41m";
$_3f641b9415 = "\x1b[43m";
$_eac55605a8 = "\x1b[46m";
$_8eb5abab18 = "\x1b[45m";
$_e12f4cfd16 = "\x1b[42m";
$_f5e65262da = "\x1b[47m";
$_3b2a7da87d = "\x1b[0m";
$_d5cbe755ab = "\x1b[1;97m";
$_9a949e3feb = "\x1b[1;30m";
$_16b2fb17d2 = "\x1b[1;31m";
$_2a4711d009 = "\x1b[1;32m";
$_56e1c26682 = "\x1b[1;33m";
$_03765ae6dd = "\x1b[1;34m";
$_8a3c272ba5 = "\x1b[1;35m";
$_b5ac604b31 = "\x1b[1;31m";
$_980b8671d9 = "\x1b[1;37m";
$_addc2093dc = "\x1b[1;32m";
$_add5c1635f = "\x1b[1;33m";
$_a2108944f6 = "\x1b[101m\x1b[1;37m";
$_36cca9c52c = "\x1b[103m\x1b[1;31m";
$_97c7eb172d = "\x1b[100m\x1b[1;32m";
$_d669072f5a = "\x1b[0m";
$_16d9af84fd = "\x1b[1;36m";
$_b986866839 = "\x1b[1;35m";
$_e8ec80c838 = "\x1b[0;30m";
$_b610ec0b57 = "\x1b[3;97m";
$_08ef5dcd43 = "\x1b[0m\x1b[3;97m";
$_0d993c851e = "\x1b[1;30m";
$_9132382bf4 = "\x1b[107m\x1b[1;31m";
$_de28deb1da = "\x1b[100m\x1b[1;33m";
$_40c79e97d2 = "\x1b[1;34m";
function c()
{
	system("clear");
}
function web($_fd16526501)
{
	$_6eead7da3e = curl_init();
	curl_setopt($_6eead7da3e, CURLOPT_URL, $_fd16526501);
	curl_setopt($_6eead7da3e, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($_6eead7da3e, CURLOPT_RETURNTRANSFER, 1);
	return curl_exec($_6eead7da3e);
}
function x($_a2de11f2f4, $_b33f6f64e1, $_34e62b750e, $_f4df5939f0)
{
	$_487481123e = explode($_a2de11f2f4, explode($_b33f6f64e1, $_34e62b750e)[$_f4df5939f0])[0];
	return $_487481123e;
}
function load($_487481123e, $_eab9a6c0d7)
{
	$_0b00e79ce3 = fopen($_eab9a6c0d7, "w");
	fwrite($_0b00e79ce3, $_487481123e);
	fclose($_0b00e79ce3);
}
function Slow($_8f60fe2e73)
{
	$_3c30ff3bab = str_split($_8f60fe2e73);
	foreach ($_3c30ff3bab as $_e42bb51ae3) {
		echo $_e42bb51ae3;
		usleep(1000);
	}
}
function g()
{
	echo slow("\x1b[1;97m──────────────────────────────────────────────────────────────────\n");
}
function Save($_7b36f41d5d)
{
	if (file_exists($_7b36f41d5d)) {
		$_487481123e = file_get_contents($_7b36f41d5d);
	} else {
		$_487481123e = readline("\x1b[1;32m Input " . $_7b36f41d5d . " :  ");
		file_put_contents($_7b36f41d5d, $_487481123e);
	}
	return $_487481123e;
}
function timer($_a84c9c9888)
{
	date_default_timezone_set("UTC");
	$_9dbccbf46b = time() + $_a84c9c9888;
	$_03765ae6dd = "\x1b[34m";
	$_44681afb95 = "\x1b[36m";
	$_8574614e03 = "\x1b[92m";
	$_0859c5d461 = "\x1b[1;97m";
	$_ed689eb69f = "\x1b[35m";
	$_95b3f712e2 = "\x1b[31m";
	$_087fc3a460 = "\x1b[33m";
	$_cad8e028af = "\x1b[8m";
	$_40e984cef9 = "\x1b[0" . "m";
	$_d698561bfa = [$_0859c5d461, $_95b3f712e2];
	$_0123e9cf97 = 0;
	$_55bb7d8d78 = [$_8574614e03, $_087fc3a460, $_44681afb95, $_8574614e03, $_087fc3a460, $_44681afb95];
	$_1bce2640ba = 1;
	while (true) {
		echo "\r														\r";
		$_dbe849e66e = $_d698561bfa[$_0123e9cf97];
		$_563fe7599f = $_9dbccbf46b - time();
		$_3fe2a570c1 = date("i:s", $_563fe7599f);
		if ($_563fe7599f < 1) {
			break;
		}
		$_d84e209146 = str_repeat("▶", $_1bce2640ba);
		$_15b3594fc6 = $_55bb7d8d78[$_1bce2640ba - 1];
		$_77537e9fc0 = "strtime ";
		$_12051cee93 = "]";
		echo "{$_0859c5d461} Please Wait", "{$_0859c5d461} {$_dbe849e66e}{$_3fe2a570c1}{$_0859c5d461} ";
		if ($_1bce2640ba == 5) {
			$_1bce2640ba = 1;
		} else {
			$_1bce2640ba++;
		}
		sleep(1);
		$_0123e9cf97++;
		if ($_0123e9cf97 >= count($_d698561bfa)) {
			$_0123e9cf97 = 0;
		}
	}
}
function base64($_d84e209146)
{
	return base64_encode($_d84e209146);
}
function get($_fd16526501)
{
	return curl($_fd16526501, null, head())[1];
}
function post($_fd16526501, $_487481123e)
{
	return curl($_fd16526501, $_487481123e, head())[1];
}
function getsolve($_8b6c50783d)
{
	return curl($_8b6c50783d, null, solve())[1];
}
function answer($_1bce2640ba, $_73ee0134e8, $_f71791bbed)
{
	if ($_1bce2640ba + $_73ee0134e8 == $_f71791bbed) {
		return "add";
	} elseif ($_1bce2640ba - $_73ee0134e8 == $_f71791bbed) {
		return "sub";
	} elseif ($_1bce2640ba * $_73ee0134e8 == $_f71791bbed) {
		return "multiply";
	} elseif ($_1bce2640ba % $_73ee0134e8) {
		return "divide";
	} else {
		return 0;
	}
}
function curl($_fd16526501, $_31feb9b40c = 0, $_3e396213a6 = 0, $_1901c07262 = 0)
{
	$_6eead7da3e = curl_init();
	curl_setopt($_6eead7da3e, CURLOPT_URL, $_fd16526501);
	curl_setopt($_6eead7da3e, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($_6eead7da3e, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($_6eead7da3e, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($_6eead7da3e, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($_6eead7da3e, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($_6eead7da3e, CURLOPT_TIMEOUT, 60);
	curl_setopt($_6eead7da3e, CURLOPT_COOKIE, true);
	if ($_31feb9b40c) {
		curl_setopt($_6eead7da3e, CURLOPT_POST, true);
		curl_setopt($_6eead7da3e, CURLOPT_POSTFIELDS, $_31feb9b40c);
	}
	if ($_3e396213a6) {
		curl_setopt($_6eead7da3e, CURLOPT_HTTPHEADER, $_3e396213a6);
	}
	if ($_1901c07262) {
		curl_setopt($_6eead7da3e, CURLOPT_HTTPPROXYTUNNEL, true);
		curl_setopt($_6eead7da3e, CURLOPT_PROXY, $_1901c07262);
	}
	curl_setopt($_6eead7da3e, CURLOPT_HEADER, true);
	$_3fb05e24d4 = curl_exec($_6eead7da3e);
	$_06de5c253c = curl_getinfo($_6eead7da3e);
	if (!$_06de5c253c) {
		return "Curl Error : " . curl_error($_6eead7da3e);
	} else {
		$_354f88ca93 = substr($_3fb05e24d4, 0, curl_getinfo($_6eead7da3e, CURLINFO_HEADER_SIZE));
		$_262bdc2deb = substr($_3fb05e24d4, curl_getinfo($_6eead7da3e, CURLINFO_HEADER_SIZE));
		curl_close($_6eead7da3e);
		return [$_354f88ca93, $_262bdc2deb];
	}
}
function head($_9f1aaeda5a)
{
	$_b75f2189d3[] = "Host: ganarbitcoindesdecuba.com";
	$_b75f2189d3[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
	$_b75f2189d3[] = "Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7";
	$_b75f2189d3[] = "Upgrade-Insecure-Requests: 1";
	$_b75f2189d3[] = "User-Agent: " . file_get_contents("user-agent");
	$_b75f2189d3[] = "Cookie: " . $_9f1aaeda5a;
	return $_b75f2189d3;
}
function solve()
{
	$_b75f2189d3[] = "Host: api-secure.solvemedia.com";
	$_b75f2189d3[] = "user-agent: " . file_get_contents("user-agent");
	$_b75f2189d3[] = "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7";
	return $_b75f2189d3;
}
function captcha()
{
	$_81fc0d0125 = file_get_contents("image.jpg");
	$_7af22f7f11 = base64($_81fc0d0125);
	$_b75f2189d3 = [];
	$_b75f2189d3[] = "User-Agent: Mozilla/5.0 (Linux; Android 11; RMX3191 Build/RP1A.200720.011;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.87 Mobile Safari/537.36";
	$_b75f2189d3[] = "content-type: application/json";
	$_6eead7da3e = curl_init();
	curl_setopt($_6eead7da3e, CURLOPT_URL, "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyC3y-Em42htSB8UEZPqptJ78rlvL58_h6Y");
	curl_setopt($_6eead7da3e, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($_6eead7da3e, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_6eead7da3e, CURLOPT_HTTPHEADER, $_b75f2189d3);
	curl_setopt($_6eead7da3e, CURLOPT_POST, 1);
	curl_setopt($_6eead7da3e, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($_6eead7da3e, CURLOPT_POSTFIELDS, '{"requests":[{"image":{"content":"' . $_7af22f7f11 . '"},"features":[{"type":"TEXT_DETECTION"}]}]}');
	$_34e62b750e = curl_exec($_6eead7da3e);
	$_bae639052c = explode('"text": "Enter the following:\\n', $_34e62b750e);
	$_8e93792918 = explode('\\n"', $_bae639052c[1]);
	$_c520d18941 = $_8e93792918[0];
	$_ddaa84b0cc = str_replace('\\n', " ", $_c520d18941);
	$_c2fcbbe684 = preg_replace("/[^a-z]/", "", $_ddaa84b0cc);
	return $_c2fcbbe684;
}
$_b5ac604b31 = "\x1b[1;31m";
$_980b8671d9 = "\x1b[1;37m";
$_addc2093dc = "\x1b[1;32m";
$_add5c1635f = "\x1b[1;33m";
$_a2108944f6 = "\x1b[101m\x1b[1;37m";
$_36cca9c52c = "\x1b[103m\x1b[1;31m";
$_97c7eb172d = "\x1b[100m\x1b[1;32m";
$_d669072f5a = "\x1b[0m";
$_16d9af84fd = "\x1b[1;36m";
$_b986866839 = "\x1b[1;35m";
$_e8ec80c838 = "\x1b[0;30m";
$_b610ec0b57 = "\x1b[3;97m";
$_08ef5dcd43 = "\x1b[0m\x1b[3;97m";
$_0d993c851e = "\x1b[1;30m";
$_9132382bf4 = "\x1b[107m\x1b[1;31m";
$_de28deb1da = "\x1b[100m\x1b[1;33m";
$_40c79e97d2 = "\x1b[1;34m";
function bk()
{

}
function banner($_1b6d96bc53)
{
	$_171755983e = json_decode(file_get_contents("http://ip-api.com/json"), true);
	$_d1ba7831c4 = $_171755983e["timezone"];
	$_f899225b31 = $_171755983e["country"];
	$_48d4b49b4f = $_171755983e["query"];
	date_default_timezone_set("{$_d1ba7831c4}");
	global $_16b2fb17d2, $_d5cbe755ab, $_2a4711d009, $_68ba588d15, $_3b2a7da87d;
	system("clear");
	$_b5ac604b31 = "\x1b[1;31m";
	$_980b8671d9 = "\x1b[1;37m";
	$_addc2093dc = "\x1b[1;32m";
	$_add5c1635f = "\x1b[1;33m";
	$_a2108944f6 = "\x1b[101m\x1b[1;37m";
	$_36cca9c52c = "\x1b[103m\x1b[1;31m";
	$_97c7eb172d = "\x1b[100m\x1b[1;32m";
	$_d669072f5a = "\x1b[0m";
	$_16d9af84fd = "\x1b[1;36m";
	$_b986866839 = "\x1b[1;35m";
	$_e8ec80c838 = "\x1b[0;30m";
	$_b610ec0b57 = "\x1b[3;97m";
	$_08ef5dcd43 = "\x1b[0m\x1b[3;97m";
	$_0d993c851e = "\x1b[1;30m";
	$_9132382bf4 = "\x1b[107m\x1b[1;31m";
	$_de28deb1da = "\x1b[100m\x1b[1;33m";
	$_40c79e97d2 = "\x1b[1;34m";
	
}
awalan:
$_5b1bdebef5 = date("D");
switch ($_5b1bdebef5) {
	case "Sat":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	case "Thu":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	case "Fri":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	case "Mon":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	case "Tue":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	case "Wed":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	case "Sun":
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
	default:
		$_0a996da2be = "";
		$_d499498ec2 = "";
		$_a0e020a360 = "";
		break;
}
$_54efdfcf06 = file_get_contents("key.txt");
if ($_54efdfcf06 != $_0a996da2be) {
	bk();
	echo " \x1b[1;32m Password 1 \x1b[1;32m: \x1b[1;97m{$_d499498ec2}\n";
	echo " \x1b[1;32m Password 2 \x1b[1;32m: \x1b[1;97m{$_a0e020a360}\n";
	$_dc10bc4850 = readline(" \x1b[1;32mInput Password \x1b[1;32m: \x1b[1;97m");
	if ($_dc10bc4850 == $_0a996da2be) {
		bk();
		load($_dc10bc4850, "key.txt");
		echo slow(" \x1b[1;32mPassword correct √√ \n");
		sleep(1);
		goto awalan;
	} else {
		bk();
		echo slow(" \x1b[1;31mWrong Password, Please Input again!\n");
		sleep(1);
		goto awalan;
	}
} else {
}
bk();
$_8b6c50783d = save("Url-Solvemedia");
$_171755983e = Save("user-agent");
$_9f1aaeda5a = save("Cookie");
system("clear");
$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/dashboard", null, head($_9f1aaeda5a))[1];
$_8730886959 = explode("<", explode('<li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown"><span class="mr-1 user-name text-bold-700">', $_34e62b750e)[1])[0];
$_ea6d777c9f = explode("<", explode('<h4 class="mb-0">', $_34e62b750e)[2])[0];
$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet", null, head($_9f1aaeda5a))[1];
$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
banner("ganarbitcoindesdecuba.com");
echo Slow("{$_36cca9c52c} •>>\x1b[0m{$_add5c1635f} Balance Account{$_40c79e97d2} => {$_addc2093dc}{$_ea6d777c9f} \n\n");
goto run;
run:
lanjut:
$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet", null, head($_9f1aaeda5a))[1];
$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
if (preg_match("/Cloudflare/", $_34e62b750e)) {
	echo "Cloudflare detect, \n";
	system("rm cookie");
	$_9f1aaeda5a = save("Cookie");
	system("clear");
	goto awalan;
	die;
}
if ($_8b08d972c9 == "Firewall") {
	goto fire;
}
$_9dbccbf46b = explode(" - 1", explode("var wait = ", $_34e62b750e)[1])[0];
if ($_9dbccbf46b != null) {
	timer($_9dbccbf46b);
}
$_f374a7d03a = explode('"', explode('csrf_token_name" id="token" value="', $_34e62b750e)[1])[0];
$_5bdef3279c = explode('"', explode('<input type="hidden" name="token" value="', $_34e62b750e)[1])[0];
$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
$_34e62b750e = curl($_8b6c50783d, null, solve())[1];
$_204f7bb16c = explode('"', explode('"challenge":"', $_34e62b750e)[1])[0];
$_34e62b750e = curl("https://api-secure.solvemedia.com/papi/media?c=" . $_204f7bb16c . ";w=300;h=150;fg=000000;bg=f8f8f8", null, solve())[1];
load($_34e62b750e, "image.jpg");
$_68562a8c91 = captcha();
if ($_68562a8c91) {
	$_bbc284771a = "+{$_c88900e8ea}+{$_9676c37c8a}+{$_a337d99d40}";
	$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet/verify", "antibotlinks=" . $_bbc284771a . "&csrf_token_name=" . $_f374a7d03a . "&token=" . $_5bdef3279c . "&captcha=solvemedia&adcopy_response=" . $_68562a8c91 . "&adcopy_challenge=" . $_204f7bb16c . "&g-recaptcha-response=&h-captcha-response=", head($_9f1aaeda5a))[1];
	$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
	if ($_8b08d972c9 == "Firewall") {
		goto fire;
	}
	$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
	$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
	$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
	$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
	$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
	$_a89dae2173 = explode(" han", explode("Excelente!', '", $_34e62b750e)[1])[0];
	echo slow(" \x1b[1;39m {$_2d21f4a274} \x1b[0m		  \r");
	if ($_2d21f4a274 != "") {
		$_bbc284771a = "+{$_c88900e8ea}+{$_a337d99d40}+{$_9676c37c8a}";
		$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet/verify", "antibotlinks=" . $_bbc284771a . "&csrf_token_name=" . $_f374a7d03a . "&token=" . $_5bdef3279c . "&captcha=solvemedia&adcopy_response=" . $_68562a8c91 . "&adcopy_challenge=" . $_204f7bb16c . "&g-recaptcha-response=&h-captcha-response=", head($_9f1aaeda5a))[1];
		$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
		$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
		$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
		$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
		$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
		$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
		$_a89dae2173 = explode(" han", explode("Excelente!', '", $_34e62b750e)[1])[0];
		echo slow(" \x1b[1;30m {$_2d21f4a274} \x1b[0m		 \r");
	}
	if ($_2d21f4a274 != "") {
		$_bbc284771a = "+{$_9676c37c8a}+{$_c88900e8ea}+{$_a337d99d40}";
		$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet/verify", "antibotlinks=" . $_bbc284771a . "&csrf_token_name=" . $_f374a7d03a . "&token=" . $_5bdef3279c . "&captcha=solvemedia&adcopy_response=" . $_68562a8c91 . "&adcopy_challenge=" . $_204f7bb16c . "&g-recaptcha-response=&h-captcha-response=", head($_9f1aaeda5a))[1];
		$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
		$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
		$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
		$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
		$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
		$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
		$_a89dae2173 = explode(" han", explode("Excelente!', '", $_34e62b750e)[1])[0];
		echo slow(" \x1b[1;33m {$_2d21f4a274} \x1b[0m		   \r");
	}
	if ($_2d21f4a274 != "") {
		$_bbc284771a = "+{$_9676c37c8a}+{$_a337d99d40}+{$_c88900e8ea}";
		$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet/verify", "antibotlinks=" . $_bbc284771a . "&csrf_token_name=" . $_f374a7d03a . "&token=" . $_5bdef3279c . "&captcha=solvemedia&adcopy_response=" . $_68562a8c91 . "&adcopy_challenge=" . $_204f7bb16c . "&g-recaptcha-response=&h-captcha-response=", head($_9f1aaeda5a))[1];
		$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
		$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
		$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
		$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
		$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
		$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
		$_a89dae2173 = explode(" han", explode("Excelente!', '", $_34e62b750e)[1])[0];
		echo slow(" \x1b[1;32m {$_2d21f4a274} \x1b[0m			  \r");
	}
	if ($_2d21f4a274 != "") {
		$_bbc284771a = "+{$_a337d99d40}+{$_9676c37c8a}+{$_c88900e8ea}";
		$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet/verify", "antibotlinks=" . $_bbc284771a . "&csrf_token_name=" . $_f374a7d03a . "&token=" . $_5bdef3279c . "&captcha=solvemedia&adcopy_response=" . $_68562a8c91 . "&adcopy_challenge=" . $_204f7bb16c . "&g-recaptcha-response=&h-captcha-response=", head($_9f1aaeda5a))[1];
		$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
		$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
		$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
		$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
		$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
		$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
		$_a89dae2173 = explode(" han", explode("Excelente!', '", $_34e62b750e)[1])[0];
		echo slow(" \x1b[1;37m {$_2d21f4a274} \x1b[0m			   \r");
	}
	if ($_2d21f4a274 != "") {
		$_bbc284771a = "+{$_a337d99d40}+{$_c88900e8ea}+{$_9676c37c8a}";
		$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/faucet/verify", "antibotlinks=" . $_bbc284771a . "&csrf_token_name=" . $_f374a7d03a . "&token=" . $_5bdef3279c . "&captcha=solvemedia&adcopy_response=" . $_68562a8c91 . "&adcopy_challenge=" . $_204f7bb16c . "&g-recaptcha-response=&h-captcha-response=", head($_9f1aaeda5a))[1];
		$_8b08d972c9 = explode("<", explode('<h4 class="card-title mb-4">', $_34e62b750e)[1])[0];
		$_c88900e8ea = explode('\\"', explode('rel=\\"', $_34e62b750e)[1])[0];
		$_9676c37c8a = explode('\\"', explode('rel=\\"', $_34e62b750e)[2])[0];
		$_a337d99d40 = explode('\\"', explode('rel=\\"', $_34e62b750e)[3])[0];
		$_9e3cbb67dc = explode("restantes<", explode('<!--   <p class="mb-0">', $_34e62b750e)[1])[0];
		$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
		$_a89dae2173 = explode(" han", explode("Excelente!', '", $_34e62b750e)[1])[0];
		echo slow(" \x1b[1;31m {$_2d21f4a274} \x1b[0m					  \r");
	}
	if ($_8b08d972c9 == "Firewall") {
		goto fire;
	}
	if ($_a89dae2173 != null) {
		$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/dashboard", null, head($_9f1aaeda5a))[1];
		$_ea6d777c9f = explode("<", explode('<h4 class="mb-0">', $_34e62b750e)[2])[0];
		echo Slow("{$_68ba588d15}{$_d5cbe755ab} •>>{$_3b2a7da87d}{$_2a4711d009} Good job!, {$_a89dae2173} has been add your account balance! \n");
		echo Slow("{$_68ba588d15}{$_d5cbe755ab} •>>{$_3b2a7da87d}{$_d5cbe755ab} Balance{$_56e1c26682} => {$_16b2fb17d2}{$_ea6d777c9f}\n");
		echo Slow("{$_68ba588d15}{$_d5cbe755ab} •>>{$_3b2a7da87d}{$_d5cbe755ab} Claim Left{$_56e1c26682} => {$_16b2fb17d2}{$_9e3cbb67dc}\n");
		g();
		system("rm image.jpg");
		goto akhir;
	} else {
		echo slow(" \x1b[1;31m Bad Captcha! \x1b[0m			\r");
		sleep(1);
		echo slow(" \x1b[1;93m									   \r");
		system("rm image.jpg");
		goto lanjut;
	}
} else {
	echo slow(" \x1b[1;37m Get Request \x1b[0m			  \r");
	system("rm image.jpg");
	goto lanjut;
}
fire:
if (file_exists("image.jpg")) {
	system("rm image.jpg");
}
$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/firewall", null, head($_9f1aaeda5a))[1];
$_5ce3688fb3 = explode('"', explode('name="csrf_token_name" value="', $_34e62b750e)[1])[0];
$_34e62b750e = curl($_8b6c50783d, null, solve())[1];
$_204f7bb16c = explode('"', explode('"challenge":"', $_34e62b750e)[1])[0];
$_34e62b750e = curl("https://api-secure.solvemedia.com/papi/media?c=" . $_204f7bb16c . ";w=300;h=150;fg=000000;bg=f8f8f8", null, solve())[1];
load($_34e62b750e, "image.jpg");
$_68562a8c91 = captcha();
if ($_68562a8c91) {
	$_34e62b750e = curl("https://ganarbitcoindesdecuba.com/firewall/verify", "adcopy_response={$_68562a8c91}&adcopy_challenge={$_204f7bb16c}&captchaType=solvemedia&csrf_token_name={$_5ce3688fb3}", head($_9f1aaeda5a))[1];
	$_2d21f4a274 = explode("<", explode('fa-exclamation-circle"></i>', $_34e62b750e)[1])[0];
	if ($_2d21f4a274 != "") {
		echo slow(" \x1b[1;31m Firewall Active!			   \r");
		sleep(1);
		echo slow(" \x1b[1;93m								\r");
		goto fire;
	}
	$_ea6d777c9f = explode("<", explode('<h4 class="mb-0">', $_34e62b750e)[2])[0];
	if ($_ea6d777c9f != "") {
		goto lanjut;
	}
} else {
	echo slow(" \x1b[1;97mBypassing Firewall				\r");
	system("rm image.jpg");
	goto fire;
}
akhir:
goto run;
