
<?php 
error_reporting(0);
date_default_timezone_set("Asia/Jakarta");
function clear() {
    system("clear");
}
clear();
/* START COLOR */
$res = "\033[0m";
$hitam = "\033[0;30m";
$abu2 = "\033[1;30m";
$putih = "\033[0;37m";
$putih2 = "\033[1;37m";
$red = "\033[0;31m";
$red2 = "\033[1;31m";
$green = "\033[92m";
$green2 = "\033[1;32m";
$yellow = "\033[0;33m";
$yellow2 = "\033[1;33m";
$blue = "\033[0;34m";
$blue2 = "\033[1;34m";
$purple = "\033[0;35m";
$purple2 = "\033[1;35m";
$lblue = "\033[0;36m";
$lblue2 = "\033[1;36m";
/* STARD BECGROUND */
$biru = "\033[44m";
$merah = "\033[41m";
$kuning = "\033[43m";
$biruM = "\033[46m";
$ungu = "\033[45m";
$hijau = "\033[42m";
$puti = "\033[47m";


function ban(){
	 $green = "\033[92m";
echo $green."
       _
  __ _(_)_   ____   ___   _
 / _` | \ \ / /\ \ / / | | |
| (_| | |\ V /  \ V /| |_| |
 \__, |_| \_/    \_/  \__, |
 |___/                |___/\n";
strip();
echo $putih."\ttelegram  : ".$green."@husanaj\n";
echo $putih."\tmessage  : ".$green."thanks to Allah SWT\n";
echo $putih."\tsupportBy  : ".$green."allMember\n";
echo $putih."\tscript  : ".$green."givvysocial\n";
strip();
}

function detik($tmr) {
	 $putih = "\033[0;37m";
	 $red = "\033[0;31m";
	 $green = "\033[92m";
	 $yellow = "\033[0;33m";
	 $blue = "\033[0;34m";
	 $lblue = "\033[0;36m";
	 $merah = "\033[41m";
 	 $putih2 = "\033[1;37m";
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
$tik = array("ðŸ™‚","ðŸ˜›","ðŸ˜","ðŸ˜œ","ðŸ¤ª");
$cop = array("ðŸ¤ª","ðŸ˜","ðŸ˜œ","ðŸ˜›","ðŸ™‚");
$ti = 0;
$color = array(
"\033[1;37m",
"\033[0;31m",
"\033[1;31m",
"\033[0;32m",
"\033[1;32m",
"\033[0;33m",
"\033[1;33m",
"\033[0;34m",
"\033[1;34m",
"\033[0;35m",
"\033[1;35m",
"\033[0;36m",
"\033[1;36m");
$v=0;

$vv=array(
"\033[0;32m",
"\033[0;36m",
"\033[0;37m",
);
$t=0;
$vou=array(
"---",
"-_-",
);
$color[rand(0,count($color)-1)];
for($i=$tmr; $i>=0; $i--){
echo $putih."[".$color[rand(0,count($color)-1)].$vou[$t].$putih."]".$vv[$v]." wait ".$merah.gmdate("H:i:s",$i).$putih." boY".$tik[$ti].$cop[$ti];
sleep(1);
echo "\r                                                       \r";
$v++;
if($v >2){
$v=0;
}
$t++;
if($t >1){
$t=0;
}

$ti++;
 if($ti >4){
  $ti=0;
}
}
echo "\r                                                \r";
}

function strip(){$putih = "\033[0;37m";
echo $putih."~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
}

function slow($var_50,$var_51){
$var_52 = str_split($var_50);
foreach ($var_52 as $var_55){
echo $var_55;
usleep($var_51);
}
}

function curl($url, $post = 0, $httpheader = 0, $proxy = 0){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_COOKIE,TRUE);
        if($post){
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if($httpheader){
            curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
        }
        if($proxy){
            curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
            curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
        }
        curl_setopt($ch, CURLOPT_HEADER, true);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch);
        if(!$httpcode) return "Curl Error : ".curl_error($ch); else{
            $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
            $body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
            curl_close($ch);
            return array($header, $body);
        }
    }

#-------------------------#
#-- metode GET dan POST --#
#-------------------------#

function curl_get($url,$host){
   return curl($url,'',$host)[1];
}
function curl_post($url,$data,$host){
  return curl($url,$data,$host)[1];
}


    function save($data,$data_post){

    if(!file_get_contents($data)){
      file_put_contents($data,"[]");
     }
    $json=json_decode(file_get_contents($data),1);
    $arr=array_merge($json,$data_post);
    file_put_contents($data,json_encode($arr,JSON_PRETTY_PRINT));

  }

#-----------------------------------------------------------------------------#
#---------------------- [CODINGAN SCRIPT NUYUL PHP] --------------------------#
#-----------------------------------------------------------------------------#

function enc($message){
$ts = round(microtime(true) * 1000);
$secret  =  b"\xc0\xf7\x07/\\r\xcavF\x96\xde.F\x87\x1d\x1c";
$cipher = "AES-128-ECB";
$option = 0;
$encrypted =  openssl_encrypt($message,$cipher,$secret,$option);
$binary = base64_decode($encrypted);
$hex = bin2hex($binary);
return $hex;
}

$host="cashagram-prod.herokuapp.com";
$header=[
"language: English",
"currency: USD",
"version: 8.9",
"packageName: com.givvysocial",
"newEra: true",
"Content-Type: application/json; charset=utf-8",
"Host: ".$host,
"Connection: Keep-Alive",
"User-Agent: okhttp/5.0.0-alpha.2",
];


   if(!file_exists("config.json")){
	 clear();ban();
	 $co=readline("deviceId: ");
	strip();
	slow($green."success".$putih.", add your account",10000);
	slow($putih.".",100000);
	slow($putih.".",100000);
	slow($putih.".",100000);
	$ts = round(microtime(true) * 1000);
        $login="https://".$host."/loginEstablished";
        $datt=json_encode([
                "deviceId" => $co,
                "versionName" => "8.9",
                "OS" => "31",
                "language" => "EN",
                "currency" => "USD",
                "waitForApprovel" => true,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$us=$res['result']['user']['id'];

	 $data = [
	 "deviceId" => $co,
	 "userId" => $us,
 	 ];
	 save("config.json",$data);
	}
	balik:
	clear();ban();
	$cfg=json_decode(file_get_contents("config.json"), true);
	$deviceId=$cfg['deviceId'];
	$user=$cfg['userId'];$licen=md5($user);

        $link_licen="https://pastebin.com/raw/BbuXnEqD";
        $res=curl_get($link_licen,["pastebin.com"]);

echo $putih."license: ".$licen."\n";
strip();
        if(strpos($res,$licen) === true){
        echo $putih."account not verifed..!\n";
        echo $putih."please contact ".$green."@husanaj\n";
        strip();
        readline("enter to back!");
        goto balik;
        }
ulangi:
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$nama=$res['result']['name'];
	$poin=$res['result']['credits'];
	$usd=$res['result']['userBalance'];
	$like=$res['result']['likesLeft'];
	$foll=$res['result']['followsLeft'];

	if($nama <= null){
	echo $putih."\rslow network, unreadable account... ";
	sleep(1);
	goto ulangi;
	}
	echo "\r                                                    \r";
	echo $blue."connect as ".$putih2.$nama.$yellow." | token_likes ".$putih.$like."\n";
        echo $lblue."\tbalance ".$green.$poin.$putih." usd ".$green.$usd."\n";
        strip();



	echo $putih."\t [1] ".$green."auto like people's posts\n";
	echo $putih."\t [2] ".$green."auto like your post\n";
	echo $putih."\t [3] ".$green."get auto followers\n";
	echo $putih."\t [4] ".$green."change coins to cash\n";
	echo $putih."\t [5] ".$green."exit\n";
	strip();
	$pop=readline($putih."options: ");

	if($pop == "" or $pop == "0" or $pop > 5 ){
	clear();ban();goto ulangi;
	}


	strip();
	switch($pop):
	case 1;
	goto post_orang;
	break;
	case 2;
	goto post_me;
	break;
	case 3;
	goto followers;
	break;
	case 4;
	goto change;break;
	case 5;
	slow($green."thanks for using this script",30000);
	slow(".",100000);
	slow(".",100000);
	slow(".",100000);
	slow("!\n",100000);
	strip();die();
	break;
	endswitch;


change:



	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res2=json_decode(curl_post($login,$datah,$header), true);

	$poin=$res2['result']['credits'];
	$nama=$res2['result']['name'];
	$usd=$res2['result']['userBalance'];


echo $putih."connect ".$green.$nama.$putih." coins ".$green.$poin.$lblue." usd ".$usd."\n";
strip();

	slow($putih."minimum exchange of 10000 points = 0.01 usd\n",40000);
	strip();
	$cek=strlen($poin);
	if($cek < 5){
	slow($red."failed".$putih.", Your points are not enough...\n",35000);
	strip();readline($putih."click enter to back!");clear();ban();goto ulangi;
	}
	echo $green."fill in the menu below, example ".$lblue."10000".$putih.",".$lblue."20000\n";
	strip();

	$tukar=readline($putih."exchange_coins: ".$green);
	strip();

	if($tukar < 10000){
	slow($red."failed".$putih.", Your points are not enough...\n",35000);
	strip();readline($putih."click enter to back!");clear();ban();goto ulangi;
	}

	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/convertCoinsToMoney";
        $datt=json_encode([
                "userId" => $user,
                "credits" => $tukar,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
	$res=$res['result'];
	$putih.print_r($res);
strip();readline($putih."click enter to back!");clear();ban();goto ulangi;




followers:
while(true):lang1:

	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/getFeedList";
        $datt=json_encode([
                "userId" => $user,
                "viewedPosts" => [],
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$cou=$res['result'];

        if(!$cou){
        goto post_me;
        }

        $fo900=count($cou);
        while(true):
        $i0000=$fo900-1;
	$Id=$res['result'][$i0000]['userId'];

/*
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $Id,
		"requestedUserId" => $Id,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$poin_law=$res['result']['credits'];
*/
	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/followUser";
        $datt=json_encode([
                "userId" => $Id,
                "userToFollow" => $user,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$text=$res['statusText'];
	$code=$res['statusCode'];

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res2=json_decode(curl_post($login,$datah,$header), true);

	$poin=$res2['result']['credits'];

if(strpos($res["statusText"], "Missing") === false){}else{
goto lang1;
}

if(strpos($res["statusText"], "have any more likes! Check your profile to see when") === false){}else{
goto lang1;
}


	if(strpos($text,"You already like this post! You can like a post only once!") === false){}else{

	$ts = round(microtime(true) * 1000);
        $login="https://".$host."/loginEstablished";
        $datt=json_encode([
                "deviceId" => $deviceId,
                "versionName" => "8.9",
                "OS" => "31",
                "language" => "EN",
                "currency" => "USD",
                "waitForApprovel" => true,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
	goto lang1;
	}

	if($code == 200){

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $Id,
		"requestedUserId" => $Id,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res2=json_decode(curl_post($login,$datah,$header), true);

	$name=$res2['result']['name'];

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res2=json_decode(curl_post($login,$datah,$header), true);

	$poin=$res2['result']['credits'];
	$foll=$res2['result']['followers'];

	date_default_timezone_set("Asia/Jakarta");
	echo $lblue."[".date("H:i:s")."]".$putih." claim status ".$green."Good job!\n";
	echo $green."\t    from   : ".$lblue.$name."\n";
	echo $green."\t    follow : ".$lblue.$foll."\n";
	strip();
	detik(rand(80,120));
	}else{

if(strpos($res["statusText"], "Missing") === false){}else{
goto lang1;
}

	if($text == "Oops! You don't have any more likes! Check your profile to see when you can like photos again!"){
	$ts = round(microtime(true) * 1000);
        $login="https://".$host."/loginEstablished";
        $datt=json_encode([
                "deviceId" => $deviceId,
                "versionName" => "8.9",
                "OS" => "31",
                "language" => "EN",
                "currency" => "USD",
                "waitForApprovel" => true,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
	goto lang1;
	}
	goto lang1;
	}
$fo900--;
if($fo900 == "0"){
goto followers;
}
endwhile;
endwhile;

post_me:
while(true):lang:
	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/getFeedList";
        $datt=json_encode([
                "userId" => $user,
                "viewedPosts" => [],
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res00=json_decode(curl_post($login,$datah,$header), true);

	$cou=$res00['result'];

        if(!$cou){
        goto post_me;
        }

        $fo90=count($cou);
        while(true):
        $i000=$fo90-1;

	$Id=$res00['result'][$i000]['userId'];

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	if($res['statusCode'] != 200){
	goto lang;
	}


	$tot=$res['result']['postPhotos'];


	if(!$tot){
	goto lang;
	}

	$coun1=count($tot);
	$coun=$coun1-1;
	if($coun == "0"){
	slow($red."failed".$putih.", You haven't uploaded an image\n",20000);
	strip();
	readline($putih."click enter to back!");
	clear();ban();goto ulangi;
	}else{
	$arr=rand(0,$coun);
	}

	$post=$res['result']['postPhotos'][$arr]['postId'];

/*
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $Id,
		"requestedUserId" => $Id,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$poin_law=$res['result']['credits'];
*/
	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/likePost";
        $datt=json_encode([
                "userId" => $Id,
                "postId" => $post,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$claim=$res['result']['earnCredits'];
	$con=$res['result']['post']['numberOfLikes'];
	$name=$res['result']['post']['likedFrom'];
	$text=$res['statusText'];


if(strpos($res["statusText"], "have any more likes! Check your profile to see when") === false){}else{
goto lang;
}

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res2=json_decode(curl_post($login,$datah,$header), true);

	$poin=$res2['result']['credits'];

	if(strpos($text,"You already like this post! You can like a post only once!") === false){}else{

	$ts = round(microtime(true) * 1000);
        $login="https://".$host."/loginEstablished";
        $datt=json_encode([
                "deviceId" => $deviceId,
                "versionName" => "8.9",
                "OS" => "31",
                "language" => "EN",
                "currency" => "USD",
                "waitForApprovel" => true,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
	goto lang;
	}

	if($claim == 50){
	date_default_timezone_set("Asia/Jakarta");
	echo $lblue."[".date("H:i:s")."]".$putih." claim status ".$green."Good job!\n";
	echo $green."\t    claim : ".$lblue."+30\n";
	echo $green."\t    from  : ".$lblue.$name."\n";
	echo $green."\t    like  : ".$lblue.$con."\n";
	echo $green."\t    poin  : ".$lblue.$poin.$putih."\n";
	strip();
	detik(rand(3,4));
	}else{
	if($text == "Oops! You don't have any more likes! Check your profile to see when you can like photos again!"){
	$ts = round(microtime(true) * 1000);
        $login="https://".$host."/loginEstablished";
        $datt=json_encode([
                "deviceId" => $deviceId,
                "versionName" => "8.9",
                "OS" => "31",
                "language" => "EN",
                "currency" => "USD",
                "waitForApprovel" => true,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
	goto lang;
	}
	goto lang;
	}
$fo90--;
if($fo90 == "0"){
goto post_me;
}
endwhile;
endwhile;

post_orang:
while(true):
	ulan:
	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/getFeedList";
        $datt=json_encode([
                "userId" => $user,
                "viewedPosts" => [],
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$cou=$res['result'];

	if(!$cou){
	goto post_orang;
	}

	$fo9=count($cou);

	while(true):
	$i00=$fo9-1;
	$Id=$res['result'][$i00]['_id'];

	$ts=round(microtime(true) * 1000);
        $login="https://".$host."/likePost";
        $datt=json_encode([
                "userId" => $user,
                "postId" => $Id,
                "verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
//print_r($res);die();

	$claim=$res['result']['earnCredits'];
	$point=$res['result']['userCredits'];
	$like=$res['result']['likesLeft'];

if(strpos($res["statusText"], "Missing") === false){}else{
goto ulan;
}

/*
if(strpos($res["statusText"], "have any more likes! Check your profile to see when") === false){}else{
echo $red."failed".$putih." open the application first, then enter\n";
strip();readline($putih."click enter to back!");clear();ban();goto ulangi;
}
*/
	if(strpos($res["statusText"],"You already like this post! You can like a post only once!") === false){}else{
	echo $red."error".$putih.", the post has been liked";
	sleep(1);
	echo "\r                                                  \r";
	goto ulan;
	}


	if($claim == 50){
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);
	$usd=$res['result']['userBalance'];

	date_default_timezone_set("Asia/Jakarta");
	echo $lblue."[".date("H:i:s")."]".$putih." claim status ".$green."Good job!\n";
	echo $green."\t    claim : ".$lblue."+".$claim."\n";
	echo $green."\t    likes : ".$lblue.$like."\n";
	echo $green."\t    point : ".$lblue.$point.$putih." usd ".$green.$usd."\n";
	strip();
	detik(rand(5,15));
	}


	if($like == 0){
	putar:
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$like1=$res['result']['likesLeft'];

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/watchVideoForMoreLikes";
        $datt=json_encode([
		"userId" => $user,
		"currentUserId" => "",
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$like=$res['result']['likesLeft'];

	if($like >= 15){
	goto ulan;
	}else{
	if($like > $like1){
	echo $lblue."     add claim likes ".$green."+".$like-$like1.$putih." total ".$green.$like."\n";
	strip();detik(rand(30,35));
	goto putar;
	}else{

	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$like0=$res['result']['likesLeft'];

	if($like0 != 0){
	goto ulan;
	}

	echo $red."failed".$putih.", claim to watch video limit";
	sleep(1);
	echo "\r                                                      \r";
	hulang:
	while(true):
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$like=$res['result']['likesLeft'];
	$time1=$res['result']['timeLeftToNextLike'];
	$tim22=strlen($time1);
	if($tim22 == "7"){
	$time=substr($time1,0,4);
	}
	if($tim22 == "6"){
	$time=substr($time1,0,3);
	}
	if($tim22 == "5"){
	$time=substr($time1,0,2);
	}
	if($tim22 == "4"){
	$time=substr($time1,0,1);
	}

	detik($time);

	cek:
	$ts=round(microtime(true) * 1000);
	$login="https://".$host."/getProfile";
        $datt=json_encode([
		"userId" => $user,
		"requestedUserId" => $user,
		"isNew" => true,
		"offset" => 0,
		"verts" => $ts
                ]);
        $datah=json_encode([
                "verificationCode" => enc($datt)
                ]);
        $res=json_decode(curl_post($login,$datah,$header), true);

	$like2=$res['result']['likesLeft'];

	$clm=$like2-$like;

	if($clm == 0){
	goto cek;
	}

	echo $green."success".$putih." add claim like ".$lblue."+ ".$clm."\n";
	strip();

	goto post_orang;

endwhile;
	}
	}

	}#seperti_awal
$fo9--;
if($fo9 == "0"){
goto post_orang;
}
endwhile;
endwhile;